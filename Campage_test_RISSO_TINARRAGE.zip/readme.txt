TP Génie Logiciel
Floréal RISSO et Téo TINARRAGE.

Le rapport .html est mieux formaté et la lecture y est plus agréable.
Le rapport .pdf est la par convention.
Si besoin il y'a le fichier brut rapport.md.

Bonne lecture.